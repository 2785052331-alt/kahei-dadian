const e={代练:"找代练上分",陪玩:"找陪玩搭子",教学:"找教学陪玩"},n={代练:"发布代练需求",陪玩:"发布陪玩需求",教学:"发布教学需求"};function o(t){return e[t]??"立即下单"}function r(t){return n[t]??"发布需求"}export{r as a,o as g};
